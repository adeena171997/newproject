 <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
               <div class="header-icon">
                  <i class="fa fa-product-hunt"></i>
               </div>
               <div class="header-title">
                  <h1>Add Category</h1>
                  <small>Add Category</small>
               </div>
            </section>
            <!-- Main content -->
            <section class="content">
               <div class="row">
                  <!-- Form controls -->
                  <div class="col-sm-12">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="btn-group" id="buttonlist"> 
                              <a class="btn btn-add " href="http://127.0.0.1:8000/admin/category/view-category"> 
                              <i class="fa fa-eye"></i>  View Categories </a>  
                           </div>
                        </div>
                        <div class="panel-body">
                           <form class="col-sm-6" action="<?php echo e(url ('/admin/category/add_category')); ?>" method="post" enctype="multipart/form-data"> 
                              <?php echo e((csrf_field())); ?>

                              <div class="form-group">
                                 <label>Category Name</label>
                                 <input type="text" class="form-control" placeholder="Enter Category Name" required name="category_name" id="category_name">
                              </div>
                            
                           
                              <div class="reset-button">
                                <input type="submit" name="submit" value="Add Category">
                                 <!-- <a href="#" class="btn btn-success">Save</a> -->
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-- /.content -->
         </div><?php /**PATH C:\xampp\htdocs\newwwproject\resources\views/admin/category/add_category.blade.php ENDPATH**/ ?>