<div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
               <div class="header-icon">
                  <i class="fa fa-product-hunt"></i>
               </div>
               <div class="header-title">
                  <h1>Add Product</h1>
                  <small>Add Product</small>
               </div>
            </section>
            <!-- Main content -->
            <section class="content">
               <div class="row">
                  <!-- Form controls -->
                  <div class="col-sm-12">
                     <div class="panel panel-bd lobidrag">
                        <div class="panel-heading">
                           <div class="btn-group" id="buttonlist"> 
                              <!-- <a class="btn btn-add " href="http://127.0.0.1:8000/admin/view_product">  -->
                              <i class="fa fa-eye"></i>  View Products </a>  
                           </div>
                        </div>
                        <div class="panel-body">
                           <form class="col-sm-6" action="<?php echo e(url ('/admin/products/add_product')); ?>" method="post" enctype="multipart/form-data"> 
                              <?php echo e((csrf_field())); ?>


                             <div class="form-group">
                                 <label>Under Category</label>
                                 <select name="category_id" id="category_id" class="form-control">
                                    <?php echo $categories_dropdown; ?>
                                 </select>
                              </div>

 <div class="form-group">

                              <div class="form-group">
                                 <label>Product Name</label>
                                 <input type="text" class="form-control" placeholder="Enter Product Name" required name="product_name" id="product_name">
                              </div>

                              <div class="form-group">
                                 <label>Product Code</label>
                                 <input type="text" class="form-control" placeholder="Enter Product Code" name="product_code" id="product_code" required>
                              </div>
                              
                              <div class="form-group">
                                 <label>Product Description</label>
                                 <input type="textarea" class="form-control" placeholder="Enter Product Description" name="product_description" id="product_description" required min="0" max="1000">
                              </div>
                             
                              <div class="form-group">
                                 <label>Product Price</label>
                                 <input type="text" class="form-control" placeholder="Enter Product Price" name="product_price" id="product_price" required>
                              </div>
                               <div class="form-group">
                                 <label>Picture upload</label>
                                 <input type="file" name="image">
                                <!--  <input type="hidden" name="old_picture"> -->
                              </div>
                            
                              <div class="reset-button">
                                <input type="submit" name="submit" value="Add Product">
                                 <!-- <a href="#" class="btn btn-success">Save</a> -->
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-- /.content -->
         </div><?php /**PATH C:\xampp\htdocs\newwwproject\resources\views/admin/products/add_product.blade.php ENDPATH**/ ?>