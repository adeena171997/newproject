
<?php $__env->startSection('content'); ?>

  <!-- Hero Section Begin -->
  
<!-- Hero Section End -->

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('frontend')); ?>/img/breadcrumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>My Order Details</h2>
                    <div class="breadcrumb__option">
                        <a href="./index.html">Home</a>
                        <span>My Order Details</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Breadcrumb Section End -->
<section class="shoping-cart spad">
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            
        </div>
        <div class="col-sm-8">
          <div class="card">
         
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">Invoice No.</th>
                        <!-- <th scope="col">Payment Type</th>
                        <th scope="col">Sub Total</th>
                        <th scope="col">Total</th> -->
                        
                      </tr>
                    </thead>
                    <tbody>
                  
                      <tr>
                      	 
                        <td><?php echo e($order->invoice_no); ?></td>
                        <!-- <td><?php echo e($order->payment_type); ?></td>
                        <td><?php echo e($order->subtotal); ?>$</td>
                        <td><?php echo e($order->total); ?>$</td> -->
                       
                      </tr>
                     
                    </tbody>
                  </table>
            </div>


         
 <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">product name</th>
                        <th scope="col">product image</th>
                        <th scope="col">product quantity</th>
                        <th scope="col">Add to cart</th>
                      </tr>
                    </thead>
                    <tbody>
               
                          <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                              <img src="<?php echo e(asset('/public/image/'.$row->product->image)); ?>" height="50px;" width="50px;" alt="img">
                             
                            </td>
                            <td>
                                <?php echo e($row->product->product_name); ?>

                            </td>

                            <td>
                                <?php echo e($row->product_qty); ?>

                            </td>
                            <td>  <form method="post" action="<?php echo e(url('add/to-friendcart/'.$row->product->id)); ?>">

                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="price" value="<?php echo e($row->product->price); ?>">
                                
                                    <!-- <a href="<?php echo e(url('add/to-cart')); ?>"><i class="fa fa-shopping-cart"></i></a> -->
                                        
                                        <button type="submit"><i class="fa fa-shopping-cart"></i></button>
                                    

                                </form></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <li><a href="<?php echo e(url('pages/profile/friendcart')); ?>"><i class="fa fa-shopping-bag"></i> </a></li>
                     
                    </tbody>
                  </table>

                 
            </div>

          <!--  -->

          </div>
        </div>
      </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newwwproject\resources\views/pages/profile/gifts-order-view.blade.php ENDPATH**/ ?>