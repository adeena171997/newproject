<!-- 
<?php $__env->startSection('admin_content'); ?>
 -->
<!-- =============================================== -->
         <!-- Content Wrapper. Contains page content -->
         
                      <!--   <div class="panel-body">
                           <form class="col-sm-6" action="<?php echo e(url ('/admin/categories')); ?>" method="post" enctype="multipart/form-data"> 
                              <?php echo e((csrf_field())); ?>

                              <div class="form-group">
                                 <label>Category Name</label>
                                 <input type="text" class="form-control" placeholder="Enter Category Name" required name="category_name" id="category_name">
                              </div>
                              <div class="form-group">
                                
                             
                              <div class="reset-button">
                                <input type="submit" name="submit" value="Add Category">
                                 
                              </div>
                          </div>
                      </form> -->
                       
         <!-- /.content-wrapper -->
<!-- <?php $__env->stopSection(); ?> -->




<div class="sl-mainpanel">
    <nav class="breadcrumb sl-breadcrumb">
      <a class="breadcrumb-item" href="index.html">Starlight</a>
      <span class="breadcrumb-item active">Dashboard</span>
    </nav>

    <div class="sl-pagebody">
      <div class="row row-sm">
        <div class="col-md-8">    
              <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">All Categories</h6>    
                <?php if(session('Catupdated')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('Catupdated')); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <?php endif; ?>

                  <?php if(session('delete')): ?>
                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong><?php echo e(session('delete')); ?></strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <?php endif; ?>
            
              </div><!-- card -->
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Add Category
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('success')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <?php endif; ?>

                    <form class="col-sm-6" action="<?php echo e(url ('/admin/categories')); ?>" method="post" enctype="multipart/form-data"> 
                              <?php echo e((csrf_field())); ?>

                              <div class="form-group">
                                 <label>Category Name</label>
                                 <input type="text" class="form-control" placeholder="Enter Category Name" required name="category_name" id="category_name">
                              </div>
                              <div class="form-group">
                                
                             
                              <div class="reset-button">
                                <input type="submit" name="submit" value="Add Category">
                                 
                              </div>
                          </div>
                      </form> 




                </div>
            </div>
        </div>
    </div>

</div>

<?php echo $__env->make('admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newwwproject\resources\views/admin/category/index.blade.php ENDPATH**/ ?>