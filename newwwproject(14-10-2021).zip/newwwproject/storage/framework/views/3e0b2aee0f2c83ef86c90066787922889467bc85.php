

<?php $__env->startSection('content'); ?>
    <!-- Hero Section Begin -->
   

    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('frontend')); ?>/img/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Checkout</h2>
                        <div class="breadcrumb__option">
                            <a href="./index.html">Home</a>
                            <span>Checkout Page</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    </section>
    <!-- Breadcrumb Section End -->

     <!-- Checkout Section Begin -->
   <!--  -->
    <!-- Checkout Section End -->
      <section class="checkout spad">
        <div class="container">
            <div class="checkout__form">
                <h4>Shipping Address</h4>
                <form action="<?php echo e(route('place-order')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-lg-8 col-md-6">
                            <div class="row">
                                <!-- <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Fist Name<span>*</span></p>
                                        <input type="text" name="shipping_first_name" value="<?php echo e(Auth::user()->name); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Last Name<span>*</span></p>
                                        <input type="text" name="shipping_last_name">
                                    </div>
                                </div> -->
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Phone Numbers<span>*</span></p>
                                        <h5>You can add multiple phone numbers with " , ".</h5>
                                        <input type="text" name="shipping_phone" >
                                    </div>
                                </div>
                               <!--  <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Email<span>*</span></p>
                                        <input type="text" name="shipping_email" value="<?php echo e(Auth::user()->email); ?>">
                                    </div>
                                </div> -->
                            </div>
                           <!--  <div class="checkout__input">
                                <p>Address<span>*</span></p>
                                <input type="text" placeholder="Street Address" class="checkout__input__add" name="address">
                            </div>
                            <div class="checkout__input">
                                <p>Country/State<span>*</span></p>
                                <input type="text" name="state">
                            </div> -->
                            <!-- <div class="checkout__input">
                                <p>Postcode / ZIP<span>*</span></p>
                                <input type="text" name="post_code">
                            </div> -->

                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="checkout__order">
                                <h4>Your Order</h4>
                                <div class="checkout__order__products">Products <span>Total</span></div>
                                <ul>
                                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($cart->product->product_name); ?> (<?php echo e($cart->qty); ?>) <span>$<?php echo e($cart->price * $cart->qty); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>


   <?php
                            $total = App\Cart::all()->where('user_ip',request()->ip())->sum(function($t){
                               return $t->price * $t->qty;
                            });
                          $quantity = App\Cart::where('user_ip',request()->ip())->sum('qty');
                        ?>

                       
                        <div class="checkout__order__subtotal">Subtotal <span>$<?php echo e($total); ?></span></div>
                        <input type="hidden" name="subtotal" value="<?php echo e($total); ?>">
                        <input type="hidden" name="total" value="<?php echo e($total); ?>">
                       
                                <h5>Select Payment Method</h5>
                                <div class="checkout__input__checkbox">
                                    <label for="payment">
                                     HansCash
                                        <input type="checkbox" id="payment" value="handcash" name="payment_type">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="checkout__input__checkbox">
                                    <label for="paypal">
                                        Paypal
                                        <input type="checkbox" id="paypal" value="paypal" name="payment_type">
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <button type="submit" class="site-btn">PLACE ORDER</button>
                            </div>
                        </div>
                    </div>

                    </div>
                    </div>
                </form>
            </div>
        </div>
    </section>

     <!-- Checkout Section Begin -->
   </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newwwproject\resources\views/pages/checkout.blade.php ENDPATH**/ ?>