
<div class="sl-mainpanel">
    <nav class="breadcrumb sl-breadcrumb">
      <a class="breadcrumb-item" href="admin/home">Admin</a>
      <span class="breadcrumb-item active">Order</span>
    </nav>

    <div class="sl-pagebody">
      <div class="row row-sm">
        <div class="col-md-12">    
              <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Order list</h6>    
                
                  <?php if(session('status')): ?>
                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <strong><?php echo e(session('status')); ?></strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <?php endif; ?>  
                  <?php if(session('delete')): ?>
                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong><?php echo e(session('delete')); ?></strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <?php endif; ?>
                <div class="table-wrapper">
                  <table id="datatable1" class="table display responsive nowrap">
                    <thead>
                      <tr>
                        <th class="wd-15p">Sl</th>
                        <th class="wd-15p">Invoice No</th>
                        <th class="wd-15p">Payment Type</th>
                        <th class="wd-20p">Total</th>  
                        <th class="wd-20p">Sub Total</th>  
                        <th class="wd-25p">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i = 1;
                        ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td>#<?php echo e($row->invoice_no); ?></td>
                        <td><?php echo e($row->payment_type); ?></td>
                        <td><?php echo e($row->total); ?>$</td>
                        <td><?php echo e($row->subtotal); ?>$</td>
                     <!--    <td>
                            <?php if($row->coupon_discount == NULL): ?>
                            <span class="badge badge-danger">No</span>
                            <?php else: ?> 
                            <span class="badge badge-success">Yes</span>
                            <?php endif; ?>
                        </td> -->
                        <td>
                            <a href="<?php echo e(url('admin/orders/view/'.$row->id)); ?>" class="btn btn-sm btn-success"><i class="fa fa-eye"></i></a>
                            <a href="<?php echo e(url('admin/coupon/delete/'.$row->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('are you shure to delete')"><i class="fa fa-trash"></i></a>
                               <a target="_blank" href="<?php echo e(url('admin/orders/view/'.$row->id)); ?>" class="btn btn-primary btn-sm" >View Order Details</a>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div><!-- table-wrapper -->
              </div><!-- card -->
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\newwwproject\resources\views/admin/order/index.blade.php ENDPATH**/ ?>