
<?php $__env->startSection('content'); ?>
    <!-- Hero Section Begin -->
       <section class="hero hero-normal">
        <div class="container">
            <div class="row">

            	<div class="col-lg-12">
                    <?php if(session('cart_delete')): ?>
                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong><?php echo e(session('cart_delete')); ?></strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <?php endif; ?>

                      <?php if(session('cart_update')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('cart_update')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <?php endif; ?>
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>All categories</span>
                        </div>

                        <?php
                             $categoriess = App\Category::where('status' , 1)->latest()->get();


                        ?>

                        <ul>

                        	<?php $__currentLoopData = $categoriess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                            	<a href="#"><?php echo e($row->category_name); ?></a>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form action="#">
                                <div class="hero__search__categories">
                                    All Categories
                                    <span class="arrow_carrot-down"></span>
                                </div>
                                <input type="text" placeholder="What do yo u need?">
                                <button type="submit" class="site-btn">SEARCH</button>
                            </form>
                        </div>
                        <div class="hero__search__phone">
                            <div class="hero__search__phone__icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="hero__search__phone__text">
                                <h5>+65 11.188.888</h5>
                                <span>support 24/7 time</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset ('frontend')); ?>/img/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Shopping Cart</h2>
                        <div class="breadcrumb__option">
                            <a href="./index.html">Home</a>
                            <span>Shopping Cart</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Shoping Cart Section Begin -->
    <section class="shoping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="shoping__cart__table">
                        <table>
                            <thead>
                                <tr>
                                    <th class="shoping__product">Products</th>
                                    <!-- <th>Price</th> -->
                                    <!-- <th>Quantity</th> -->
                                    <!-- <th>Total</th> -->
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="shoping__cart__item">
                                        <img height ='100' width='100'src="<?php echo e(asset('/public/image/'.$cart->product->image)); ?>"  alt="">
                                        <h5><?php echo e($cart->product->product_name); ?></h5>
                                    </td>

                                   <!--  <td class="shoping__cart__product name">
                                        <h5><?php echo e($cart->product->product_name); ?></h5>
                                    </td> -->
                                 <!--    <td class="shoping__cart__price">
                                        <?php echo e($cart->product->price); ?>

                                    </td> -->
                                   

                                     <!-- <td class="shoping__cart__quantity">
                                        <div class="quantity">
                                        <form action="<?php echo e(url('cart/quantity/update/'.$cart->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="pro-qty">
                                                <input type="text" name="qty" value="<?php echo e($cart->qty); ?>" min="1">
                                            </div>
                                            <button type="submit" class="btn btn-sm btn-success">Update</button>
                                        </form>
                                        </div>
                                    </td> -->
                                
                                  <!--   <td class="shoping__cart__total">
                                        <?php echo e($cart->qty *$cart->product->price); ?>

                                    </td>
                                    <td class="shoping__cart__item__close">
                                    	<a href="<?php echo e(url('cart/destroy/'.$cart->id)); ?>">

                                        <span class="icon_close"></span>
                                    </td> -->
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- <div class="col-lg-12">
                    <div class="shoping__cart__btns">
                        <a href="#" class="primary-btn cart-btn">CONTINUE SHOPPING</a>
                        <a href="#" class="primary-btn cart-btn cart-btn-right"><span class="icon_loading"></span>
                            Upadate Cart</a>
                    </div>
                </div> -->
                <!-- <div class="col-lg-6">
                    <div class="shoping__continue">
                        <div class="shoping__discount">
                            <h5>Discount Codes</h5>
                            <form action="#">
                                <input type="text" placeholder="Enter your coupon code">
                                <button type="submit" class="site-btn">APPLY COUPON</button>
                            </form>
                        </div>
                    </div>
                </div> -->

                <div class="col-lg-6">
                    <div class="shoping__checkout">
                      
                       
                        <a href="<?php echo e(url('checkout')); ?>" class="primary-btn">PROCEED TO CHECKOUT</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shoping Cart Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newwwproject\resources\views/pages/profile/friendcart.blade.php ENDPATH**/ ?>