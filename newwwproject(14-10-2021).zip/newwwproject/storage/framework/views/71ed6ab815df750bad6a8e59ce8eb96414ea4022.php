<!DOCTYPE html>
<html>
<head>
	<title>form</title>
</head>
<body>
<form action="/profile/order" method='post'>
	<?php echo csrf_field(); ?>
	<input type="text" name="name" value="name" placeholder="enter name">
	<input type="text" name="shipping_phone" value="shipping_phone" placeholder="enter phone no">
	<input type="submit" name="submit" value="submit">
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\newwwproject\resources\views/pages/Friends/friendspage.blade.php ENDPATH**/ ?>