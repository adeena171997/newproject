<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shipping extends Model
{
   /**
    * The attributes that aren't mass assignable.
    *
    * @var array
    */
    // protected $guarded = [];
   protected $fillable = [
         'order_id','shipping_phone'
    ];
}
