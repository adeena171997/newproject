<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Shipping;
use App\OrderItem;
use App\Order;
use App\Cart;
use Auth;
class FriendController extends Controller
{
    //

    public function compare(Request $request){
    	$v=$request->input("shipping_phone");
     	$data=DB::select('select id from shippings where Shipping_phone=?',[$v]);
      if($data=$v)
      {
        
        return redirect('pages/profile/gifts');


      }
      else{
        return redirect('/pages/profile/friendspage');
      }


    	}

      public function order(){
      // $shipping = Shipping::where('shipping_phone',$shipping_phone)->get();
       $order = Order::where ('user_id',Auth::id())->latest()->get();
       return view('pages.profile.giftorder',compact('order'));
    }

    public function orderview($order_id){

      $order = Order::findOrFail($order_id);
      $orderItems = OrderItem::where('order_id',$order_id)->get();
      // $shipping = Shipping::where('order_id',$order_id)->first();
      return view('pages.profile.gifts-order-view',compact('orderItems','order'));
    }


     public function addToCart(Request $request,$product_id){
     // echo request()->ip();
     // die();
        $check = Cart::where('product_id',$product_id)->where('user_ip',request()->ip())->first();
        if ($check) {
            Cart::where('product_id',$product_id)->where('user_ip',request()->ip())->increment('qty');
            return Redirect()->back()->with('cart','Product added On Cart');
        }else{
            Cart::insert([
                'product_id' => $product_id,
                'qty' => 1,
                'price' => $request->price,
                'user_ip' => request()->ip(),
            ]);
            return Redirect()->back()->with('cart','Product added On Cart');
        }
        
    }
    public function CartPage(Request $request){
       
           
 $carts = Cart::where('user_ip',request()->ip())->latest()->get();
return view('pages.profile.friendcart',compact('carts'));

}
}