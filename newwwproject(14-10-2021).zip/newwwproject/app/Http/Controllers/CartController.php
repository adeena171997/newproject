<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Cart;
use App\Shipping;
use Auth;
class CartController extends Controller
{

    //

    public function addToCart(Request $request,$product_id){
     // echo request()->ip();
     // die();
        $check = Cart::where('product_id',$product_id)->where('user_ip',request()->ip())->first();
        if ($check) {
            Cart::where('product_id',$product_id)->where('user_ip',request()->ip())->increment('qty');
            return Redirect()->back()->with('cart','Product added On Cart');
        }else{
            Cart::insert([
                'product_id' => $product_id,
                'qty' => 1,
                'price' => $request->price,
                // s
                'user_ip' => request()->ip(),
            ]);
            return Redirect()->back()->with('cart','Product added On Cart');
        }
        
    }


    public function CartPage(Request $request){
        if (Auth::check()) {
           
 $carts = Cart::where('user_ip',request()->ip())->latest()->get();
return view('pages.cart',compact('carts'));
}else{
    return redirect()->route('login');
}


 
    }
      public function destroy($cart_id){
        Cart::where('id',$cart_id)->where('user_ip',request()->ip())->delete();
        return Redirect()->back()->with('cart_delete','Cart Product Removed');
    }


    public function update(Request $request,$cart_id){
        Cart::where('id',$cart_id)->where('user_ip',request()->ip())->update([
            'qty' => $request->qty,
        ]);
        return Redirect()->back()->with('cart_update','Quantity Updated');
    }

}
