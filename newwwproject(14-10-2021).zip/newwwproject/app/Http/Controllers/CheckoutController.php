<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\checkout;
use App\Cart;
use App\Shipping;
class CheckoutController extends Controller
{
    //

   
   public function index(){
      
            $carts = Cart::latest()->get();
           $total = Cart::all()->where('user_ip',request()->ip())->sum(function($t){
            return $t->price * $t->qty;
        });
        return view('pages.checkout', compact('carts','total'));
     
      
   }

  public function showcartitem(Request $request){
 $carts = Cart::where('user_ip',request()->ip())->latest()->get();
return view('pages.checkout',compact('carts'));
 
    }


    // public function show() 
    // {
    //     return view("add-remove-multiple-input-fields");
    // }
    // public function store(Request $request)
    // {
    //     $request->validate([
    //         'moreFields.*.shipping_phone' => 'required',
            
    //     ]);
     
    //     foreach ($request->moreFields as $key => $value) {
    //        Shipping::create($value);
    //     }
     
    //     return back()->with('success', 'Your Data Has Been Successfully Save.');
    // }

}


