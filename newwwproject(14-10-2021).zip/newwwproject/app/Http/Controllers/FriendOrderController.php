<?php

namespace App\Http\Controllers;
Use App\FriendOrder;
use App\Shipping;
use App\Cart;
use Carbon\Carbon;
use App\Order;
use Auth;
use Illuminate\Http\Request;

class FriendOrderController extends Controller
{
    //

    // 
    public function storeOrder(Request $request){

       
    


        //  $order_id = Order::insertGetId([
        //     'user_id' => Auth::id(),
        //     'invoice_no' => mt_rand(10000000,99999999),
        //     'payment_type' => $request->payment_type,
        //     'total' => $request->total,
        //     'subtotal' => $request->subtotal,
        //     'coupon_discount' => $request->coupon_discount,
        //     'created_at' => Carbon::now(),
        // ]);


       

        $carts = Cart::where('user_ip',request()->ip())->latest()->get();
        $Shipping = Shipping::get();
            foreach ($carts as $cart ) {
          foreach($Shipping as $shippings){
                FriendOrder::insert([
                    'shipping_phone' => $shippings->shipping_phone,
                    'product_id' => $cart->product_id,
                    'product_qty' => $cart->qty,
                    'created_at' => Carbon::now(),
                ]);

            }
        }
 // $request->validate([
 //            'moreFields.* shipping_phone' => 'required',
 //            'order_id' => $order_id,
 //        ]);
 //           foreach ($request->moreFields as $key => $value) {
 //           Shipping::create($value);
           
 //        }

         // Shipping::insert([
         //        'order_id' => $order_id,
                 
         //    ]);
// $request->validate([
//             'moreFields.* shipping_phone' => 'required',
//               'moreFields.* order_id' => 'required',
//         ]);

//            foreach ($request->moreFields as $key => $value) {
//            Shipping::create($value);
           
//         }
           // Shipping::insert([
           //      'order_id' => $order_id,
               
           //      'shipping_phone' => $request->shipping_phone,
               
           //  ]);
              
// 
            

            

         Cart::where('user_ip',request()->ip())->delete();


            return Redirect()->to('order/success')->with('orderComplete','Your Order Succeffully Done');



    }

    public function orderSuccess(){
        return view('pages.order-complete');
    }
}


