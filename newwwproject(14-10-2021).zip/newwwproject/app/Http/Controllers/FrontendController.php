<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;
use App\Cart;
class FrontendController extends Controller
{
    //
    public function index ()
    {
    	$products = Product::where('status' , 1)->latest()->get();
    	$catergories = Category::where('status' , 1)->latest()->get();
    	return view('pages.index', compact('products','catergories'));
    }


    public function productdetails($product_id){
    	  $product = Product::findOrFail($product_id);
    	  
    	return view('pages.product-details',compact('product'));
    }

    public function updatequantity(Request $request,$Cart_id){

 Cart::where('id',$cart_id)->where('user_ip',request()->ip())->update([
            'qty' => $request->qty,
        ]);
        return Redirect()->back()->with('cart_update','Quantity Updated');
    
    }
}
