<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Category;
class CategoryController extends Controller
{
    //
   public function index(){
        $categories = Category::latest()->get();
        return view('admin.category.index',compact('categories'));
    }

    public function addcategory(Request $request){

    	if($request->ismethod('post'))
    	{
    		$data = $request->all();
    		$category = new Category;
    		$category->category_name = $data['category_name'];
    		
    		$category->save();
    		return redirect('/admin/categories');
    	}
    	
    	return view('admin.category.index');
    }
}
