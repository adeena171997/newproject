<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Product;
use App\Category;
class ProductController extends Controller
{
    //

    public function addproduct(Request $request)
    {
    	if($request->ismethod('post'))
    	{
    		$data = $request->all();
    		// echo "<pre>";print_r($data);die;
    		$product = new Product;
       
            $product->category_id = $data['category_id'];
           $product->product_quantity = $data['product_quantity'];
    		$product->product_name = $data['product_name'];
    		$product->product_code = $data['product_code'];
             $product->price = $data['price'];
    		if(!empty($data['description'])){
    			$product->description = $data['description'];
    		}
    		else
    		{
    			$product->description ='';
    		}

    	

    		//upload image
       if ($files = $request->file('image')) {
         $destinationPath = 'public/image/';
            // upload path
            // $destinationPath = 'upload/image/';
           $profileImage = date('YmdHis') . "." . $files->getClientOriginalExtension();
           $files->move($destinationPath, $profileImage);
           $insert['image'] = "$profileImage";
           $product->image= $profileImage;
        }
       
    		$product->save();
    		return redirect('/admin/product/add')->with('flash_message_success','product has been successfully added!!');


    	}
    	 $categories = Category::get();
        $categories_dropdown = "<option value='' selected disabled>Select</option>";
        foreach($categories as $cat){
            $categories_dropdown .= "<option value='".$cat->id."'>".$cat->category_name."</option>";
        }
      
        // return view('admin.add_product')->with(compact('categories_dropdown'));
        return view('admin.product.add')->with(compact('categories_dropdown'));
    }
}


