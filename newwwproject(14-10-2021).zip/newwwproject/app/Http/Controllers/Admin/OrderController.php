<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Order;
use App\orderitem;
use App\Shipping;
class OrderController extends Controller
{
    //
       public function index(){
    $orders=Order::latest()->get();

       	return view('admin.order.index',compact('orders'));
       }
       public function viewOrder ($order_id){

       	$order = Order::Findorfail($order_id);
       	$orderitem = OrderItem::where('order_id',$order_id)->get();
       	$shipping = Shipping::where('order_id',$order_id)->first();
       	return view('admin.order.view', compact('order','orderitem','shipping'));
       }
}
