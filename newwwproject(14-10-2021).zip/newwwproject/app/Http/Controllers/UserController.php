<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\OrderItem;
use App\ shipping;
use Auth;
class UserController extends Controller
{
    //
    public function order(){

       $order = Order::where ('user_id',Auth::id())->latest()->get();
       return view('pages.profile.order',compact('order'));
    }

    public function orderview($order_id){

    	$order = Order::findOrFail($order_id);
    	$orderItems = OrderItem::where('order_id',$order_id)->get();
    	$shipping = Shipping::where('order_id',$order_id)->first();
    	return view('pages.profile.order-view',compact('order','orderItems','shipping'));
    }
}
