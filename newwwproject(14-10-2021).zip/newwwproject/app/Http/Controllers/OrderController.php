<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cart;
use App\Order;
use App\OrderItem;
use App\Shipping;
use Carbon\Carbon;
Use App\FriendOrder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    // 
    public function storeOrder(Request $request){

       

        $order_id = Order::insertGetId([
            'user_id' => Auth::id(),
            'invoice_no' => mt_rand(10000000,99999999),
            'payment_type' => $request->payment_type,
            'total' => $request->total,
            'subtotal' => $request->subtotal,
            'coupon_discount' => $request->coupon_discount,
            'created_at' => Carbon::now(),
        ]);

        $carts = Cart::where('user_ip',request()->ip())->latest()->get();
        // $shipping = Shipping::where('order_id',$order_id)->latest()->get();
            foreach ($carts as $cart ) {
          // foreach ($shipping as $shipping ) {
              
          
                OrderItem::insert([
                    'order_id' => $order_id,
                    // 'shipping_id'=>$shipping->shipping_id,
                    'product_id' => $cart->product_id,
                    'product_qty' => $cart->qty,
                    
                    'created_at' => Carbon::now(),

                ]);

            // }
            }
 // $request->validate([
 //            'moreFields.* shipping_phone' => 'required',
 //            'order_id' => $order_id,
 //        ]);
 //           foreach ($request->moreFields as $key => $value) {
 //           Shipping::create($value);
           
 //        }

         // Shipping::insert([
         //        'order_id' => $order_id,
                 
         //    ]);
// $request->validate([
//             'moreFields.* shipping_phone' => 'required',
//               'moreFields.* order_id' => 'required',
//         ]);

//            foreach ($request->moreFields as $key => $value) {
//            Shipping::create($value);
           
//         }
           Shipping::insert([
                'order_id' => $order_id,
               
                'shipping_phone' => $request->shipping_phone,
               
            ]);

              
            

            

         Cart::where('user_ip',request()->ip())->delete();


            return Redirect()->to('order/success')->with('orderComplete','Your Order Succeffully Done');



    }

    public function orderSuccess(){
        return view('pages.order-complete');
    }
}
