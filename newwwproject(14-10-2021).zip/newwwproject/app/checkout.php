<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class checkout extends Model
{
    //
      protected $table="checkouts";
   public $primarykey="id";
   public $timestamp=true;
}
