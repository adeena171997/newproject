<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
    'category_id','product_name','product_slug','product_code','product_quantity','description','price','image','status',
    ];

    public function category(){
        return $this->belongsTo(Category::class, 'category_id');
    }
}
