<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::get('/', 'HomeController@index')->name('home');

// admin
Route::get('/admin/home', 'HomeController@redirects');
// Route::get('/admin/home', 'HomeController@redirects')->name('redirects');
// Route::get('/admin/admin', function () {
//     return view('admin.admin');
// });
Route::match(['get','post'],'/','FrontendController@index');
// Route::get('/admin/home', function () {
//     return view('admin/home');
// });
//**********************************Admin Route*************************************//

// Category Section

Route::match(['get','post'],'admin/categories','Admin\CategoryController@index');

Route::match(['get','post'] , 'admin/categories' , 'Admin\CategoryController@addcategory');


Route::match(['get','post'] , 'admin/product/add' , 'Admin\ProductController@addproduct');


// --------------------Cart-----------------------//


Route::post('add/to-cart/{product_id}','CartController@addToCart');

Route::match(['get','post'], 'cart' ,'CartController@CartPage');

Route::get('cart/destroy/{cart_id}', 'CartController@destroy');

Route::post('cart/quantity/update/{cart_id}', 'CartController@update');



// -----------------------------Product Details---------------------//

Route::get('product/details/{product_id}', 'FrontendController@productdetails');

// Route::post('cart/quantity/update/{cart_id}', 'FrontendController@updatequantity');



// -------------------------Checkout-------------------------------//

Route::match(['get','post'],'checkout','CheckoutController@index');
Route::match(['get','post'], 'checkout' ,'CheckoutController@showcartitem');


Route::post('place/order', 'OrderController@storeorder')->name('place-order');
// Route::post('place/order', 'FriendOrderController@storeorder')->name('place-order');

Route::match(['post','get'], 'order/success' ,'OrderController@orderSuccess');

//--------------------User Order-----------------------//


Route::get('user/order', 'UserController@order')->name('user.order');
Route::get('user/order-view/{id}' , 'UserController@orderview');


// ----------------------------Friends------------------------//

// Route::match(['get','post'],'pages/Friends/friendspage','FriendController@index');
Route::get('/pages/profile/friendspage', function () {
    return view('/pages/profile/friendspage');
});
// Route::match(['get','post'],'/pages/Friends/friendspage','FriendController@saveadminlogin');
Route::match(['get','post'],'/profile/friendspage','FriendController@compare');

Route::post('/pages/profile/compare', 'FriendController@compare');
Route::get('/pages/profile/compare', 'FriendController@compare');

Route::get('/pages/profile/gifts', function () {
    return view('/pages/profile/gifts');
});



Route::get('user/giftorder', 'FriendController@order')->name('user.giftorder');
Route::get('user/gifts-order-view/{id}' , 'FriendController@orderview');



Route::post('add/to-friendcart/{product_id}','FriendController@addToCart');
Route::match(['get','post'], 'pages/profile/friendcart' ,'FriendController@CartPage');

// Route::match(['get','post'],'/profile/friendspage','Auth\RegisterController@compare');
//---------Admin Order Route----------------------------//

Route::match(['get','post'],'admin/orders','Admin\OrderController@index');
Route::get('admin/orders/view/{id}','Admin\OrderController@viewOrder');

// ------------auth route------------------------//
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
// Route::match(['get','post'],'/profile/friendspage','Auth\RegisterController@compare');