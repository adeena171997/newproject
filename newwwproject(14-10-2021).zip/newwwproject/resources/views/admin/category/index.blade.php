<!-- @extends('admin.admin-master')
@section('admin_content')
 -->
<!-- =============================================== -->
         <!-- Content Wrapper. Contains page content -->
         
                      <!--   <div class="panel-body">
                           <form class="col-sm-6" action="{{url ('/admin/categories')}}" method="post" enctype="multipart/form-data"> 
                              {{(csrf_field())}}
                              <div class="form-group">
                                 <label>Category Name</label>
                                 <input type="text" class="form-control" placeholder="Enter Category Name" required name="category_name" id="category_name">
                              </div>
                              <div class="form-group">
                                
                             
                              <div class="reset-button">
                                <input type="submit" name="submit" value="Add Category">
                                 
                              </div>
                          </div>
                      </form> -->
                       
         <!-- /.content-wrapper -->
<!-- @endsection -->




<div class="sl-mainpanel">
    <nav class="breadcrumb sl-breadcrumb">
      <a class="breadcrumb-item" href="index.html">Starlight</a>
      <span class="breadcrumb-item active">Dashboard</span>
    </nav>

    <div class="sl-pagebody">
      <div class="row row-sm">
        <div class="col-md-8">    
              <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">All Categories</h6>    
                @if(session('Catupdated'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>{{session('Catupdated')}}</strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  @endif

                  @if(session('delete'))
                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong>{{session('delete')}}</strong>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    @endif
            
              </div><!-- card -->
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Add Category
                </div>

                <div class="card-body">
                    @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>{{session('success')}}</strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      @endif

                    <form class="col-sm-6" action="{{url ('/admin/categories')}}" method="post" enctype="multipart/form-data"> 
                              {{(csrf_field())}}
                              <div class="form-group">
                                 <label>Category Name</label>
                                 <input type="text" class="form-control" placeholder="Enter Category Name" required name="category_name" id="category_name">
                              </div>
                              <div class="form-group">
                                
                             
                              <div class="reset-button">
                                <input type="submit" name="submit" value="Add Category">
                                 
                              </div>
                          </div>
                      </form> 




                </div>
            </div>
        </div>
    </div>

</div>
