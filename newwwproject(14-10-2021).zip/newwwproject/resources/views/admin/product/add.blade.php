
<div class="sl-mainpanel">
    <nav class="breadcrumb sl-breadcrumb">
      <a class="breadcrumb-item" href="index.html">Admin</a>
      <span class="breadcrumb-item active">Add Products</span>
    </nav>

    <div class="sl-pagebody">
      <div class="row row-sm">
      
        <div class="card pd-20 pd-sm-40">
            <h6 class="card-body-title">Add New Products</h6>
        <form action="{{url ('/admin/product/add')}}" method="POST" enctype="multipart/form-data">
            @csrf
           
                              <div class="form-group">
                                 <label>Product Name</label>
                                 <input type="text" class="form-control" placeholder="Enter Product Name" required name="product_name" id="product_name">
                              </div>

                              <div class="form-group">
                                 <label>Product Code</label>
                                 <input type="text" class="form-control" placeholder="Enter Product Code" name="product_code" id="product_code" required>
                              </div>

                <div class="form-group">
                                 <label>Product Quanity</label>
                                 <input type="text" class="form-control" placeholder="Enter Product Quanity" name="product_quantity" id="product_quantity" required>
                              </div>

                              <div class="form-group">
                                 <label>Product Price</label>
                                 <input type="text" class="form-control" placeholder="Enter Product Price" name="price" id="price" required>
                              </div>
              <div class="form-group">
                                 <label>Under Category</label>
                                 <select name="category_id" id="category_id" class="form-control">
                                    <?php echo $categories_dropdown; ?>
                                 </select>
                              </div>
              
                    <div class="form-group">
                                 <label>Product Description</label>
                                 <input type="textarea" class="form-control" placeholder="Enter Product Description" name="description" id="description" required min="0" max="1000">
                              </div>


                 <div class="form-group">
                                 <label>Picture upload</label>
                                 <input type="file" name="image">
                                <!--  <input type="hidden" name="old_picture"> -->
                              </div>           
                  
              </div><!-- row -->
  
              <div class="form-layout-footer">
                <button class="btn btn-info mg-r-5">Add Products</button>
              </div><!-- form-layout-footer -->
            </form>
            </div><!-- form-layout -->
          </div><!-- card -->
    </div>

</div>
