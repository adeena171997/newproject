@extends('layouts.frontend-master')
@section('content')

  <!-- Hero Section Begin -->
  
<!-- Hero Section End -->

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="{{ asset('frontend') }}/img/breadcrumb.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>My Order Details</h2>
                    <div class="breadcrumb__option">
                        <a href="./index.html">Home</a>
                        <span>My Order Details</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Breadcrumb Section End -->
<section class="shoping-cart spad">
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            
        </div>
        <div class="col-sm-8">
          <div class="card">
         
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">Invoice No.</th>
                        <!-- <th scope="col">Payment Type</th>
                        <th scope="col">Sub Total</th>
                        <th scope="col">Total</th> -->
                        
                      </tr>
                    </thead>
                    <tbody>
                  
                      <tr>
                      	 
                        <td>{{ $order->invoice_no }}</td>
                        <!-- <td>{{$order->payment_type }}</td>
                        <td>{{ $order->subtotal }}$</td>
                        <td>{{ $order->total }}$</td> -->
                       
                      </tr>
                     
                    </tbody>
                  </table>
            </div>


         
 <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">product name</th>
                        <th scope="col">product image</th>
                        <th scope="col">product quantity</th>
                        <th scope="col">Add to cart</th>
                      </tr>
                    </thead>
                    <tbody>
               
                          @foreach ($orderItems as $row)
                        <tr>
                          <td>
                              <img src="{{asset('/public/image/'.$row->product->image)}}" height="50px;" width="50px;" alt="img">
                             
                            </td>
                            <td>
                                {{ $row->product->product_name }}
                            </td>

                            <td>
                                {{ $row->product_qty }}
                            </td>
                            <td>  <form method="post" action="{{url('add/to-friendcart/'.$row->product->id)}}">

                                    @csrf

                                    <input type="hidden" name="price" value="{{$row->product->price}}">
                                
                                    <!-- <a href="{{url('add/to-cart')}}"><i class="fa fa-shopping-cart"></i></a> -->
                                        
                                        <button type="submit"><i class="fa fa-shopping-cart"></i></button>
                                    

                                </form></td>
                        </tr>
                        @endforeach
           <li><a href="{{ url('pages/profile/friendcart') }}"><i class="fa fa-shopping-bag"></i> </a></li>
                     
                    </tbody>
                  </table>

                 
            </div>

          <!--  -->

          </div>
        </div>
      </div>
</div>
</section>
@endsection
