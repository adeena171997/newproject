<!DOCTYPE html>
<html>
<head>
	<title>form</title>
</head>
<body>
<form action="compare"method='post'>
	@csrf
	<input type="text" name="name" value="name" placeholder="enter name">
	<input type="text" name="shipping_phone" value="shipping_phone" placeholder="enter phone no">
	<input type="submit" name="submit" value="submit">
</form>
</body>
</html>